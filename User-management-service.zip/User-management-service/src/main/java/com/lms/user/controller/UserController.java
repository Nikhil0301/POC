package com.lms.user.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.lms.user.dtos.UserSupportInfo;
import com.lms.user.dtos.UserTO;
import com.lms.user.response.GenericResponse;
import com.lms.user.service.UserManagementService;

import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;

@RestController
@RequestMapping("/user")
@Validated
public class UserController {
	
	@Autowired
	private UserManagementService userService;
	
	@Autowired
    private UserSupportInfo userSupportInfo;
	
	//create user
	@ResponseStatus(HttpStatus.CREATED)
	@RequestMapping(method = RequestMethod.POST , path = "/create-user")
	public GenericResponse<UserTO> createUser(@RequestBody UserTO userTo) {
		UserTO user = userService.createUser(userTo);
		return new GenericResponse<UserTO>("User successfully created",GenericResponse.SUCCESS,HttpStatus.OK.value(),userTo);
	}
	
	//get all users
	@RequestMapping(method = RequestMethod.GET)
	public ResponseEntity<Page<UserTO>> getUsers() {
		Page<UserTO> pageData = userService.getUsers();
		return ResponseEntity.status(HttpStatus.OK).body(pageData);
	}
	
	//get user by id
	@RequestMapping(value = "/{id}", method = RequestMethod.GET)
	public ResponseEntity<UserTO> getUser(@PathVariable(required = true) Integer id) {
	    UserTO userto= userService.getUserById(id);
		return ResponseEntity.status(HttpStatus.OK).body(userto);
	}
	
	//delete user by id
	@RequestMapping(value = "/{id}", method = RequestMethod.DELETE)
	public void deleteUser(@PathVariable(required = true) Integer id) {
		userService.deleteUserById(id);
	}
	
	@GetMapping("/user-support-info")
    public ResponseEntity<UserSupportInfo> getContactInfo() {
        return ResponseEntity
                .status(HttpStatus.OK)
                .body(userSupportInfo);
    }
}
