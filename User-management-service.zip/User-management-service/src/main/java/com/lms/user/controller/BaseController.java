package com.lms.user.controller;

import org.springframework.web.bind.annotation.RequestBody;

import com.lms.user.constant.RestAPIConstants;
import com.lms.user.dtos.UserTO;
import com.lms.user.response.GenericResponse;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@ApiResponses({
		@ApiResponse(code = RestAPIConstants.HTTP200, message = RestAPIConstants.OK, response = GenericResponse.class),
		@ApiResponse(code = RestAPIConstants.HTTP204, message = RestAPIConstants.NOCONTENT, response = GenericResponse.class),
		@ApiResponse(code = RestAPIConstants.HTTP400, message = RestAPIConstants.BADREQ),
		@ApiResponse(code = RestAPIConstants.HTTP401, message = RestAPIConstants.UNAUTH),
		@ApiResponse(code = RestAPIConstants.HTTP403, message = RestAPIConstants.FORBID),
		@ApiResponse(code = RestAPIConstants.HTTP404, message = RestAPIConstants.NOTFOUND),
@ApiResponse(code = RestAPIConstants.HTTP500, message = RestAPIConstants.SERVERERROR) })
@Api(value = "BusinessApplications", tags = "Business Application API Info")
public interface BaseController {
	
	@ApiOperation(value = "Create Business application")
	@ApiImplicitParams({ @ApiImplicitParam(name = "LOGGED_IN_USER", paramType = "header") })
	public GenericResponse<UserTO>  createUser(
			@RequestBody UserTO userTo);
	
	
	
}
