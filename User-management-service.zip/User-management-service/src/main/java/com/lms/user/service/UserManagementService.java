package com.lms.user.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import com.lms.user.dtos.UserTO;
import com.lms.user.entities.User;
import com.lms.user.exception.ResourceNotFoundException;
import com.lms.user.mapper.UserDBMapper;
import com.lms.user.repository.UserRepository;

@Service
public class UserManagementService {
	
	@Autowired
	private UserDBMapper userDbMapper;
	
	@Autowired
	private UserRepository userRepo;
	
	public UserTO createUser(UserTO userTo) {
		//check if the user already exist
		//if already exist throws exception, otherwise map the userto to user entity
	    Optional<User> user = userRepo.findByEmail(userTo.getEmail());
		
	    User newUser = userDbMapper.getMappedObject(userTo);
		
	    userRepo.save(newUser);
	    
		return userDbMapper.getReverseMappedObject(newUser);
		
	}
	
	public PageImpl<UserTO> getUsers() {
	
	    List<User> users = userRepo.findAll();
	    long totalCount = userRepo.count();
		List<UserTO> userslist =  new ArrayList();
		for(User user:users) {
			userslist.add(userDbMapper.getReverseMappedObject(user));
		}
		
		PageRequest pageable = PageRequest.of(0,5);
		return new PageImpl<>(userslist, pageable, totalCount);
	}
	
	public UserTO getUserById(Integer id) {
	    User user = userRepo.findById(id).orElseThrow(() -> new ResourceNotFoundException("User","id",String.valueOf(id)));
	    return userDbMapper.getReverseMappedObject(user);
	}
	
	public void deleteUserById(Integer id) {
		User user = userRepo.findById(id).orElseThrow(() -> new ResourceNotFoundException("User","id",String.valueOf(id)));
	    userRepo.delete(user);
	}
}
