package com.example.lms.bookservice.service;

import com.example.lms.bookservice.model.Book;
import java.util.List;
import java.util.Optional;

public interface BookService {
    List<Book> getAllBooks();
    Optional<Book> getBookById(int id);
    Book saveBook(Book book);
    void deleteBook(int id);
    Book updateBook(int id, Book bookDetails);
}